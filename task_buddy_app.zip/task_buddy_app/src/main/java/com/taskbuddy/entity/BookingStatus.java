package com.taskbuddy.entity;

public enum BookingStatus {
    PENDING,
    ACCEPTED,
    COMPLETED,
    CANCELLED
}
