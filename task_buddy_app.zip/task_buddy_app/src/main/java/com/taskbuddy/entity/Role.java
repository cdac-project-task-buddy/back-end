package com.taskbuddy.entity;

public enum Role {
    CUSTOMER,
    TASKER,
    ADMIN
}
